#ifdef _M_IX86
    #include "vpx_config_x86.h"
#endif
#ifdef _M_X64
    #include "vpx_config_x86_64.h"
#endif
